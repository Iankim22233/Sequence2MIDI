#!/usr/bin/env python3
"""
Decode a proprietary keyboard `.sequence` file (protobuf-encoded note list)
into a standard MIDI file.

Usage:
    sequence_to_midi.py <input.sequence> [output.mid]

Format notes (reverse-engineered, not an official spec):
  - Top-level protobuf stream: one header submessage (field 1), followed by
    repeated note-event submessages (field 2).
  - Each note event has:
      field 1 (varint)         -> MIDI pitch
      field 2 (fixed32 float)  -> start time, in 1/16-note units (0 if omitted)
      field 3 (fixed32 float)  -> duration, in 1/16-note units
      field 4 (varint)         -> General MIDI program number (0-127) for this note
      field 5 (fixed32 float)  -> velocity / 127.0
  - Notes are grouped by field 4 into one MIDI track per instrument, each on
    its own channel with the matching GM program change.
  - No explicit tempo field was found; output defaults to 120 BPM.
"""

import struct
import sys
import os

GM_PROGRAM_NAMES = [
    "Acoustic Grand Piano", "Bright Acoustic Piano", "Electric Grand Piano", "Honky-tonk Piano",
    "Electric Piano 1", "Electric Piano 2", "Harpsichord", "Clavinet", "Celesta", "Glockenspiel",
    "Music Box", "Vibraphone", "Marimba", "Xylophone", "Tubular Bells", "Dulcimer",
    "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ", "Reed Organ", "Accordion",
    "Harmonica", "Tango Accordion", "Acoustic Guitar (nylon)", "Acoustic Guitar (steel)",
    "Electric Guitar (jazz)", "Electric Guitar (clean)", "Electric Guitar (muted)",
    "Overdriven Guitar", "Distortion Guitar", "Guitar Harmonics", "Acoustic Bass",
    "Electric Bass (finger)", "Electric Bass (pick)", "Fretless Bass", "Slap Bass 1",
    "Slap Bass 2", "Synth Bass 1", "Synth Bass 2", "Violin", "Viola", "Cello", "Contrabass",
    "Tremolo Strings", "Pizzicato Strings", "Orchestral Harp", "Timpani", "String Ensemble 1",
    "String Ensemble 2", "Synth Strings 1", "Synth Strings 2", "Choir Aahs", "Voice Oohs",
    "Synth Voice", "Orchestra Hit", "Trumpet", "Trombone", "Tuba", "Muted Trumpet",
    "French Horn", "Brass Section", "Synth Brass 1", "Synth Brass 2", "Soprano Sax",
    "Alto Sax", "Tenor Sax", "Baritone Sax", "Oboe", "English Horn", "Bassoon", "Clarinet",
    "Piccolo", "Flute", "Recorder", "Pan Flute", "Blown Bottle", "Shakuhachi", "Whistle",
    "Ocarina", "Lead 1 (square)", "Lead 2 (sawtooth)", "Lead 3 (calliope)", "Lead 4 (chiff)",
    "Lead 5 (charang)", "Lead 6 (voice)", "Lead 7 (fifths)", "Lead 8 (bass+lead)",
    "Pad 1 (new age)", "Pad 2 (warm)", "Pad 3 (polysynth)", "Pad 4 (choir)", "Pad 5 (bowed)",
    "Pad 6 (metallic)", "Pad 7 (halo)", "Pad 8 (sweep)", "FX 1 (rain)", "FX 2 (soundtrack)",
    "FX 3 (crystal)", "FX 4 (atmosphere)", "FX 5 (brightness)", "FX 6 (goblins)",
    "FX 7 (echoes)", "FX 8 (sci-fi)", "Sitar", "Banjo", "Shamisen", "Koto", "Kalimba",
    "Bagpipe", "Fiddle", "Shanai", "Tinkle Bell", "Agogo", "Steel Drums", "Woodblock",
    "Taiko Drum", "Melodic Tom", "Synth Drum", "Reverse Cymbal", "Guitar Fret Noise",
    "Breath Noise", "Seashore", "Bird Tweet", "Telephone Ring", "Helicopter", "Applause",
    "Gunshot",
]


def gm_program_name(program):
    if 0 <= program < len(GM_PROGRAM_NAMES):
        return GM_PROGRAM_NAMES[program]
    return f"Program {program}"


def read_varint(data, i):
    result = 0
    shift = 0
    while True:
        b = data[i]
        result |= (b & 0x7F) << shift
        i += 1
        if not (b & 0x80):
            break
        shift += 7
    return result, i


def parse_note(sub):
    i = 0
    n = len(sub)
    fields = {}
    while i < n:
        tag, i = read_varint(sub, i)
        field_no = tag >> 3
        wire = tag & 0x7
        if wire == 0:
            val, i = read_varint(sub, i)
        elif wire == 5:
            val = struct.unpack('<f', sub[i:i + 4])[0]
            i += 4
        elif wire == 1:
            val = struct.unpack('<d', sub[i:i + 8])[0]
            i += 8
        elif wire == 2:
            length, i = read_varint(sub, i)
            val = sub[i:i + length]
            i += length
        else:
            raise ValueError(f"unsupported wire type {wire} in note record")
        fields[field_no] = val
    return fields


def extract_notes(data):
    i = 0
    n = len(data)

    # top-level field 1 = header submessage; skip it
    tag, i = read_varint(data, i)
    if (tag >> 3) != 1 or (tag & 0x7) != 2:
        raise ValueError("unexpected file layout: missing header (field 1)")
    length, i = read_varint(data, i)
    i += length

    notes = []
    while i < n:
        tag, i = read_varint(data, i)
        field_no = tag >> 3
        wire = tag & 0x7
        if field_no != 2 or wire != 2:
            raise ValueError(f"unexpected top-level field {field_no} (wire {wire}) at byte {i}")
        length, i = read_varint(data, i)
        sub = data[i:i + length]
        i += length
        notes.append(parse_note(sub))
    return notes


def vlq(n):
    out = [n & 0x7F]
    n >>= 7
    while n:
        out.append((n & 0x7F) | 0x80)
        n >>= 7
    return bytes(reversed(out))


def build_track(events, channel, program):
    track = bytearray()
    track += vlq(0) + bytes([0xC0 | channel, program & 0x7F])
    last_tick = 0
    for tick, _prio, status, note, vel in events:
        delta = tick - last_tick
        last_tick = tick
        track += vlq(delta) + bytes([status | channel, note, vel])
    track += vlq(0) + bytes([0xFF, 0x2F, 0x00])  # end of track
    return b'MTrk' + struct.pack('>I', len(track)) + bytes(track)


def build_midi(notes, ticks_per_beat=480, bpm=120):
    unit = ticks_per_beat // 4  # 4 file-units == 1 quarter note

    by_program = {}
    for nt in notes:
        program = int(nt.get(4, 0)) & 0x7F
        pitch = int(nt.get(1, 0)) & 0x7F
        start = nt.get(2, 0.0)
        dur = nt.get(3, 0.0)
        vel = max(1, min(127, round(nt.get(5, 0.5) * 127)))
        start_tick = round(start * unit)
        end_tick = round((start + dur) * unit)
        if end_tick <= start_tick:
            end_tick = start_tick + 1
        group = by_program.setdefault(program, [])
        group.append((start_tick, 1, 0x90, pitch, vel))
        group.append((end_tick, 0, 0x80, pitch, 0))

    # channel 9 is reserved for percussion in General MIDI; skip it for our
    # melodic program-per-track assignment
    channels = [c for c in range(16) if c != 9]

    tempo_track = bytearray()
    micros_per_beat = round(60_000_000 / bpm)
    tempo_track += vlq(0) + bytes([0xFF, 0x51, 0x03]) + micros_per_beat.to_bytes(3, 'big')
    tempo_track += vlq(0) + bytes([0xFF, 0x2F, 0x00])
    tempo_chunk = b'MTrk' + struct.pack('>I', len(tempo_track)) + bytes(tempo_track)

    track_chunks = [tempo_chunk]
    instrument_summary = []
    for idx, program in enumerate(sorted(by_program.keys())):
        channel = channels[idx % len(channels)]
        events = sorted(by_program[program], key=lambda e: (e[0], e[1]))
        track_chunks.append(build_track(events, channel, program))
        instrument_summary.append((program, gm_program_name(program), len(by_program[program]) // 2, channel))

    ntrks = len(track_chunks)
    header = b'MThd' + struct.pack('>IHHH', 6, 1, ntrks, ticks_per_beat)
    return header + b''.join(track_chunks), instrument_summary


def convert(input_path, output_path=None):
    with open(input_path, 'rb') as f:
        data = f.read()

    notes = extract_notes(data)
    if not notes:
        raise ValueError("no note events found")

    midi_bytes, instrument_summary = build_midi(notes)

    if output_path is None:
        base, _ext = os.path.splitext(input_path)
        output_path = base + '.mid'

    with open(output_path, 'wb') as f:
        f.write(midi_bytes)

    return output_path, len(notes), instrument_summary


def main():
    if len(sys.argv) < 2:
        print("usage: sequence_to_midi.py <input.sequence> [output.mid]", file=sys.stderr)
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    out_path, note_count, instrument_summary = convert(input_path, output_path)
    print(out_path)
    print(f"{note_count} notes", file=sys.stderr)
    for program, name, count, channel in instrument_summary:
        print(f"  ch{channel + 1:>2} program {program:>3} ({name}): {count} notes", file=sys.stderr)


if __name__ == '__main__':
    main()
