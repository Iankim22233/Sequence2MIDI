#!/usr/bin/env python3
"""
Encode a standard MIDI file into the reverse-engineered `.sequence` format
used by sequence_to_midi.py (see that file for the note-record schema).

Usage:
    midi_to_sequence.py <input.mid> [output.sequence]

IMPORTANT CAVEAT: the note-record schema (pitch/start/duration/program/
velocity) was confirmed by decoding real .sequence files. The *header* that
precedes the note list clearly carries real per-song data too (see the
comment in build_sequence() below), but its exact meaning was never fully
decoded. This encoder emits a minimal placeholder header. Files produced
here will decode correctly with sequence_to_midi.py, but there's no
guarantee the original app that reads .sequence files will accept a file
with a placeholder header -- if it rejects the file or misbehaves, that's
the header, not the note data.
"""

import struct
import sys
import os


def read_varint(data, i):
    result = 0
    shift = 0
    while True:
        b = data[i]
        result |= (b & 0x7F) << shift
        i += 1
        if not (b & 0x80):
            break
        shift += 7
    return result, i


def read_midi_vlq(data, i):
    """
    Standard MIDI variable-length quantity: big-endian 7-bit groups (each
    earlier byte is shifted left by the ones after it), continuation bit
    means "more bytes follow". This is NOT the same bit layout as protobuf's
    LEB128 varints (read_varint above) despite the superficial similarity --
    mixing the two up silently produces wildly wrong numbers for any value
    spanning more than one byte, which is what happened here.
    """
    result = 0
    while True:
        b = data[i]
        i += 1
        result = (result << 7) | (b & 0x7F)
        if not (b & 0x80):
            break
    return result, i


def write_varint(n):
    """Protobuf-style LEB128: low-order 7-bit group first, continuation bit
    on every byte but the last. (Opposite group order from MIDI's VLQ --
    see read_midi_vlq above.)"""
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def tag_bytes(field_no, wire):
    return write_varint((field_no << 3) | wire)


def field_varint(field_no, value):
    return tag_bytes(field_no, 0) + write_varint(value)


def field_float(field_no, value):
    return tag_bytes(field_no, 5) + struct.pack('<f', value)


def field_bytes(field_no, raw):
    return tag_bytes(field_no, 2) + write_varint(len(raw)) + raw


# ---- standard MIDI file parsing ----

def parse_midi(data):
    assert data[0:4] == b'MThd', "not a standard MIDI file (missing MThd)"
    header_len = struct.unpack('>I', data[4:8])[0]
    fmt, ntrks, division = struct.unpack('>HHH', data[8:8 + header_len])
    if division & 0x8000:
        raise ValueError("SMPTE time division is not supported")
    ticks_per_beat = division

    i = 8 + header_len
    tracks = []
    while i < len(data):
        chunk_type = data[i:i + 4]
        chunk_len = struct.unpack('>I', data[i + 4:i + 8])[0]
        chunk_data = data[i + 8:i + 8 + chunk_len]
        i += 8 + chunk_len
        if chunk_type == b'MTrk':
            tracks.append(chunk_data)
    return ticks_per_beat, tracks


def parse_track_events(track):
    """Returns (events, tempo_microseconds_per_beat_or_None) for a track.
    events holds channel events only; the tempo (if a Set Tempo meta event
    is present) is pulled out separately since it drives the header's BPM
    field rather than any note."""
    i = 0
    n = len(track)
    tick = 0
    running_status = None
    events = []
    tempo = None
    while i < n:
        delta, i = read_midi_vlq(track, i)
        tick += delta
        status_byte = track[i]
        if status_byte < 0x80:
            # running status: reuse previous status byte, this byte is data
            status = running_status
            data_start = i
        else:
            status = status_byte
            i += 1
            data_start = i
            if status < 0xF0:
                running_status = status

        if status is None:
            break

        if status == 0xFF:
            meta_type = track[data_start]
            length, j = read_midi_vlq(track, data_start + 1)
            if meta_type == 0x51 and length == 3:
                tempo = int.from_bytes(track[j:j + 3], 'big')
            i = j + length
            continue
        elif status in (0xF0, 0xF7):
            length, j = read_midi_vlq(track, data_start)
            i = j + length
            continue

        hi = status & 0xF0
        channel = status & 0x0F
        if hi in (0x80, 0x90, 0xA0, 0xB0, 0xE0):
            d1, d2 = track[data_start], track[data_start + 1]
            i = data_start + 2 if status_byte >= 0x80 else data_start + 1
            events.append((tick, hi, channel, d1, d2))
        elif hi in (0xC0, 0xD0):
            d1 = track[data_start]
            i = data_start + 1 if status_byte >= 0x80 else data_start
            events.append((tick, hi, channel, d1, None))
        else:
            # unknown status; bail out of this track rather than mis-parse
            break
    return events, tempo


def extract_notes(ticks_per_beat, tracks):
    unit = ticks_per_beat / 4.0  # 4 file-units == 1 quarter note

    notes = []
    tempo = None
    for track in tracks:
        events, track_tempo = parse_track_events(track)
        if track_tempo is not None and tempo is None:
            tempo = track_tempo
        program = [0] * 16       # current GM program per channel
        active = {}               # (channel, pitch) -> stack of (start_tick, velocity, program)
        for tick, hi, channel, d1, d2 in events:
            if hi == 0xC0:
                program[channel] = d1
            elif hi == 0x90 and d2 > 0:
                active.setdefault((channel, d1), []).append((tick, d2, program[channel]))
            elif hi == 0x80 or (hi == 0x90 and d2 == 0):
                key = (channel, d1)
                if active.get(key):
                    start_tick, vel, prog = active[key].pop(0)
                    start = start_tick / unit
                    dur = max(tick - start_tick, 1) / unit
                    notes.append({
                        1: d1,
                        2: start,
                        3: dur,
                        4: prog,
                        5: vel / 127.0,
                    })
    notes.sort(key=lambda nt: nt[2])
    bpm = round(60_000_000 / tempo) if tempo else 120
    return notes, bpm


# ---- .sequence encoding ----

def encode_note(nt):
    out = bytearray()
    out += field_varint(1, int(nt[1]) & 0x7F)
    if nt[2] != 0.0:
        out += field_float(2, nt[2])
    out += field_float(3, nt[3])
    if nt[4] != 0:
        out += field_varint(4, int(nt[4]) & 0x7F)
    out += field_float(5, nt[5])
    return bytes(out)


def build_header(bpm):
    """
    Minimal placeholder header. Real .sequence headers observed in the wild
    carry a nested summary block (repeated small records plus a block with
    fields resembling duration/measure/time-signature data) whose exact
    semantics were not decoded -- see the module docstring. Field 1 here is
    confirmed to be read directly as the song's BPM (an earlier version of
    this encoder put the note count there instead, which is why converted
    songs played back at absurd tempos).
    """
    inner = field_varint(1, bpm)
    return field_bytes(1, inner)


def build_sequence(notes, bpm):
    out = bytearray()
    out += build_header(bpm)
    for nt in notes:
        out += field_bytes(2, encode_note(nt))
    return bytes(out)


def convert(input_path, output_path=None):
    with open(input_path, 'rb') as f:
        data = f.read()

    ticks_per_beat, tracks = parse_midi(data)
    notes, bpm = extract_notes(ticks_per_beat, tracks)
    if not notes:
        raise ValueError("no note events found in MIDI file")

    seq_bytes = build_sequence(notes, bpm)

    if output_path is None:
        base, _ext = os.path.splitext(input_path)
        output_path = base + '.sequence'

    with open(output_path, 'wb') as f:
        f.write(seq_bytes)

    return output_path, len(notes), bpm


def main():
    if len(sys.argv) < 2:
        print("usage: midi_to_sequence.py <input.mid> [output.sequence]", file=sys.stderr)
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    out_path, note_count, bpm = convert(input_path, output_path)
    print(out_path)
    print(f"{note_count} notes, {bpm} BPM", file=sys.stderr)


if __name__ == '__main__':
    main()
